"""
 * @file   : materialVideo.py
 * @time   : 15:23
 * @date   : 2024/3/23
 * @mail   : 9727005@qq.com
 * @creator: ShanDong Xiedali
 * @company: HiLand & RainyTop
"""
from JianyingDraft.core.material import Material


class MaterialVideo(Material):
    def __init__(self):
        super().__init__()

    pass


pass
