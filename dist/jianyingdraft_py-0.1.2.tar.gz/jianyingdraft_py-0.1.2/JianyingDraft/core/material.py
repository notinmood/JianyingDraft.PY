"""
 * @file   : material.py
 * @time   : 15:17
 * @date   : 2024/3/23
 * @mail   : 9727005@qq.com
 * @creator: ShanDong Xiedali
 * @company: HiLand & RainyTop
"""


class Material:
    """
    素材的基类
    """
    def __init__(self):
        pass


pass
